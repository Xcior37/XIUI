--Zone: Reisenjima Sanctorium
--Zone ID: 293
return {
    Names = {
        ['Cloud of Darkness'] = { Name='Cloud of Darkness', Notorious=true, Aggro=false, Link=false, TrueSight=false, Job=0, MinLevel=130, MaxLevel=130, Immunities=0, Respawn=0, Sight=true, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Darkness'] = { Name='Darkness', Notorious=true, Aggro=false, Link=false, TrueSight=false, Job=0, MinLevel=130, MaxLevel=130, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=0.5, Ice=0.5, Wind=0.5, Earth=0.5, Lightning=0.5, Water=0.5, Light=0.5, Dark=0.5} },
    },
    Indices = {
    },
};