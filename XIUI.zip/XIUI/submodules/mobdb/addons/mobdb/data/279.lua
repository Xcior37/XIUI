--Zone: Walk of Echoes [P2]
--Zone ID: 279
return {
    Names = {
    },
    Indices = {
    },
};